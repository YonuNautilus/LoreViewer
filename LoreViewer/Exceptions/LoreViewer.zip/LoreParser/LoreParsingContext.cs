﻿namespace LoreViewer.Parser
{
  public class LoreParsingContext
  {
    public string FilePath;
    public LoreParsingContext(string filePath) { FilePath = filePath; }
  }
}

﻿using LoreViewer.Exceptions.SettingsParsingExceptions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using YamlDotNet.Serialization;
using YamlDotNet.Serialization.NamingConventions;

namespace LoreViewer.Settings
{
  /// <summary>
  /// Represents the Lore's schema with all references hooked up (the post-processed raw settings deserialized directly from YAML)
  /// </summary>
  public class LoreSettings
  {
    const string LoreSettingsFileName = "Lore_Settings.yaml";

    public List<LoreTypeDefinition> types = new List<LoreTypeDefinition>();
    public List<LoreCollectionDefinition> collections = new List<LoreCollectionDefinition>();
    public AppSettings Settings { get; set; }

    public string FolderPath { get; set; }

    private bool m_bHadFatalError;
    public bool HadFatalError { get => m_bHadFatalError; }

    public LoreSettings()
    {

    }

    public bool HasTypeDefinition(string typeName) => types.Any(type => type.name.Equals(typeName));
    public LoreTypeDefinition GetTypeDefinition(string typeName) => types.FirstOrDefault(type => type.name.Equals(typeName));
    public bool HasCollectionDefinition(string collectionName) => collections.Any(col => col.name.Equals(collectionName));
    public LoreCollectionDefinition GetCollectionDefinition(string typeName) => collections.FirstOrDefault(type => type.name.Equals(typeName));



    public static LoreSettings ParseSettingsFromFolder(string folderPath)
    {
      string fullSettingsPath = Path.Combine(folderPath, LoreSettingsFileName);
      if (!File.Exists(fullSettingsPath))
        throw new Exception($"Did not find file {fullSettingsPath}");


      var deserializer = new DeserializerBuilder().WithNamingConvention(CamelCaseNamingConvention.Instance).Build();

      string settingsText = File.ReadAllText(fullSettingsPath);

      LoreSettings newSettings = deserializer.Deserialize<LoreSettings>(settingsText);
      newSettings.FolderPath = folderPath;

      newSettings.PostProcess();

      return newSettings;
    }


    public void PostProcess()
    {
      CheckDuplicateNames();

      ResolveTypeInheritance();

      ResolveReferencedTypes();
    }

    private void CheckDuplicateNames()
    {
      IEnumerable<LoreDefinitionBase> defsWithSameName = types.Concat<LoreDefinitionBase>(collections).GroupBy(d => d.name).Where(group => group.Count() > 1).SelectMany(def => def);
      if (defsWithSameName.Any())
      {
        throw new DuplicateDefinitionNamesException(defsWithSameName.First());
      }
    }

    private void ResolveTypeInheritance()
    {
      List<LoreTypeDefinition> typesInheritanceOrder = InheritanceOrderedTypeDefinition(types);

      foreach (LoreTypeDefinition ltd in typesInheritanceOrder)
      {
        if (!string.IsNullOrWhiteSpace(ltd.extends))
        {
          LoreTypeDefinition parentType = GetTypeDefinition(ltd.extends);
          ltd.SetParent(parentType);
        }
      }
    }

    private void ResolveReferencedTypes()
    {
      foreach (LoreTypeDefinition ltd in types)
        if (!ltd.processed)
          ltd.PostProcess(this);

      foreach (LoreCollectionDefinition lcd in collections)
        lcd.PostProcess(this);
    }

    /// <summary>
    /// Resolving inheritance is no laughing matter. We must ensure resolving inheritance is done in the correct order.
    /// This method takes all embeddedNodeDefs, and gives a list of the LoreTypeDefinitions in an order that will not break inheritance
    /// when inheritance resolution occurs.
    /// </summary>
    /// <param name="allTypes"></param>
    /// <returns></returns>
    private List<LoreTypeDefinition> InheritanceOrderedTypeDefinition(List<LoreTypeDefinition> allTypes)
    {
      List<LoreTypeDefinition> res = new List<LoreTypeDefinition>();
      HashSet<string> visited = new HashSet<string>();
      HashSet<string> visiting = new HashSet<string>();
      Dictionary<string, LoreTypeDefinition> typesMapping = allTypes.ToDictionary(ltd => ltd.name, ltd => ltd);

      void visit(string typeName)
      {

        if (!typesMapping.ContainsKey(typeName))
          throw new InheritingMissingTypeDefinitionException(typeName);

        LoreTypeDefinition type = typesMapping[typeName];

        if (visited.Contains(typeName)) return;
        if (visiting.Contains(typeName))
          throw new CyclicalInheritanceException(type);

        visiting.Add(typeName);

        if (!string.IsNullOrWhiteSpace(type.extends))
          visit(type.extends);

        visiting.Remove(typeName);
        visited.Add(typeName);
        res.Add(type);
      }

      foreach (LoreTypeDefinition type in allTypes)
        visit(type.name);

      return res;
    }
  }
  public class AppSettings
  {
    public bool ignoreCase { get; set; }
    public bool softLinking { get; set; } = false;
    public string defaultSort { get; set; } = string.Empty;
    public List<string> markdownExtensions { get; set; } = new List<string>();
    public List<string> blockedPaths { get; set; } = new List<string>();
  }
}

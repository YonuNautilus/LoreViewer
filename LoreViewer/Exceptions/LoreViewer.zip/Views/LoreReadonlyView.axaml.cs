using Avalonia.Controls;

namespace LoreViewer.Views;

public partial class LoreReadonlyView : UserControl
{
  public LoreReadonlyView()
  {
    InitializeComponent();
  }
}
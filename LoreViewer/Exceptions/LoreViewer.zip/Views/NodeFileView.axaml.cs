using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace LoreViewer;

public partial class NodeFileView : UserControl
{
    public NodeFileView()
    {
        InitializeComponent();
    }
}
using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace LoreViewer.Views;

public partial class LoreNodeView : UserControl
{
    public LoreNodeView()
    {
        InitializeComponent();
    }
}
using Avalonia.Controls;
using Avalonia.Interactivity;
using LoreViewer.ViewModels.SettingsVMs;

namespace LoreViewer.Views;

public partial class LoreSettingsView : UserControl
{
  public LoreSettingsView()
  {
    InitializeComponent();
  }
}
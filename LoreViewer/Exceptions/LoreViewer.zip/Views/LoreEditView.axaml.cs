using Avalonia.Controls;

namespace LoreViewer.Views;

public partial class LoreEditView : UserControl
{
  public LoreEditView()
  {
    InitializeComponent();
  }
}
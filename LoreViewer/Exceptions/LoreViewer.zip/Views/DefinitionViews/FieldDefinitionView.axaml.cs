using LoreViewer.ViewModels.SettingsVMs;

namespace LoreViewer.Views.DefinitionViews;

public partial class FieldDefinitionView : DefinitionView
{
  public FieldDefinitionView() : base() { }

  public FieldDefinitionView(FieldDefinitionViewModel definitionViewModel) : base(definitionViewModel) { }
}
﻿using ReactiveUI;

namespace LoreViewer.ViewModels
{
  public class ViewModelBase : ReactiveObject
  {
  }
}
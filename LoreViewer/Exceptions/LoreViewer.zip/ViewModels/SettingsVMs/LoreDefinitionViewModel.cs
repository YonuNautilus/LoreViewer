﻿using Avalonia;
using Avalonia.Interactivity;
using DocumentFormat.OpenXml.Wordprocessing;
using LoreViewer.Settings;
using LoreViewer.Settings.Interfaces;
using ReactiveUI;
using System;
using System.Reactive;
using System.Reflection.Metadata;

namespace LoreViewer.ViewModels.SettingsVMs
{
  public abstract class LoreDefinitionViewModel
  {
    private Visual m_oView;
    public void SetView(Visual visual) => m_oView = visual;
    public ReactiveCommand<LoreDefinitionViewModel, Unit> DeleteDefinitionCommand { get; }
    public ReactiveCommand<LoreDefinitionViewModel, Unit> EditDefinitionCommand { get; }
    public LoreDefinitionBase Definition { get; }

    public string Name { get => Definition.name; set => Definition.name = value; }


    public LoreDefinitionViewModel SelectedItem { get; set; }

    protected LoreDefinitionViewModel(LoreDefinitionBase definitionBase)
    {
      Definition = definitionBase;
    }
    public abstract void RefreshLists();

    public void DeleteDefinition(LoreDefinitionViewModel viewModel)
    {
      switch (viewModel)
      {
        case TypeDefinitionViewModel typeDefVM:
          break;
        case FieldDefinitionViewModel fieldDefVM:
          if (Definition is IFieldDefinitionContainer ifdc)
          {
            ifdc.fields.Remove(fieldDefVM.Definition as LoreFieldDefinition);
            /*switch (this)
            {
              case TypeDefinitionViewModel tdvm:
                tdvm.Fields.Remove(fieldDefVM);
              case FieldDefinitionViewModel fdvm:
                fdvm.
            }*/
          }
          break;
        case SectionDefinitionViewModel sectionDefVM:
          if (Definition is ISectionDefinitionContainer isdc)
            isdc.sections.Remove(sectionDefVM.Definition as LoreSectionDefinition);
          break;
        case CollectionDefinitionViewModel collectionDefVM:
          if (Definition is ICollectionDefinitionContainer icdc)
            icdc.collections.Remove(collectionDefVM.Definition as LoreCollectionDefinition);
          break;
        case EmbeddedNodeDefinitionViewModel embeddedNodeDefVM:
          if (Definition is IEmbeddedNodeDefinitionContainer iendc)
            iendc.embeddedNodeDefs.Remove(embeddedNodeDefVM.Definition as LoreEmbeddedNodeDefinition);
          break;
        default: return;
      }
    }

    public void EditDefinition(LoreDefinitionViewModel viewModel)
    {

    }
  }
}

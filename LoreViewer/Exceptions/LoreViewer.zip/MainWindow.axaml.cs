using Avalonia.Controls;

namespace LoreViewer
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    public void AddControl(Control control)
    {
      MainGrid.Children.Add(control);
    }
  }
}